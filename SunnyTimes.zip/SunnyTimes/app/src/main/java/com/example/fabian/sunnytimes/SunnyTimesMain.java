package com.example.fabian.sunnytimes;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import android.content.*;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class SunnyTimesMain extends AppCompatActivity {

    private String url;
    private TextView sunrise;
    private TextView sunset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sunny_times_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        sunrise = (TextView) findViewById(R.id.sunrise);
        sunset = (TextView) findViewById(R.id.sunset);
    }

    public void UpdateData(View v){

        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            String stringUrl = "http://api.openweathermap.org/data/2.5/forecast/city?id=524901&APPID=510a5b8562f4a12b10819d0ca723fc68";
            new DownloadWebpageTask().execute(stringUrl);
        } else {
            Toast.makeText(SunnyTimesMain.this, "Network connection ERROR", Toast.LENGTH_LONG).show();
        }
    }

    private class DownloadWebpageTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            // params comes from the execute() call: params[0] is the url.
            try {
                return downloadUrl(urls[0]);
            } catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            String[] data = null;
            data = result.split(";");
            sunrise.setText(data[0]);
            sunset.setText(data[1]);
        }
    }

    private String downloadUrl(String myurl) throws IOException {
        InputStream is = null;
        // Only display the first 500 characters of the retrieved
        // web page content.
        int len = 500;

        try {
            URL url = new URL(myurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 /* milliseconds */);
            conn.setConnectTimeout(15000 /* milliseconds */);
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            // Starts the query
            conn.connect();
            int response = conn.getResponseCode();
            is = conn.getInputStream();

            // Convert the InputStream into a string
            String contentAsString = readIt(is, len);
            return contentAsString;

            // Makes sure that the InputStream is closed after the app is
            // finished using it.
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

    public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[len];

        String result = null;

        String sBuffer = String.valueOf(buffer);
        if(sBuffer.contains("sun")){
            int iName = sBuffer.indexOf("<name>");
            int iSet = sBuffer.indexOf("set=\"");
            int iRise = sBuffer.indexOf("rise=\"");
            String sName = sBuffer.substring(sBuffer.indexOf("<name>")+6,sBuffer.indexOf("</name>"));
            String sRise = sBuffer.substring(sBuffer.indexOf('"', iRise) + 1, sBuffer.indexOf('"', iRise+6)).replaceAll("T", "\nTime: ");
            String sSet = sBuffer.substring(sBuffer.indexOf('"', iSet) + 1, sBuffer.indexOf('"', iSet+6)).replaceAll("T", "\nTime: ");
            result = sRise + ";" + sSet;
        }
        else{
            result = "ERROR;ERROR";
        }

        return result;
    }
}